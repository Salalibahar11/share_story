const CONFIG = {
  BASE_URL: 'https://cors-anywhere.herokuapp.com/https://story-api.dicoding.dev/v1',
};

export default CONFIG;